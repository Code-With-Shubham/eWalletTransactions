package com.home.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.home.beans.ChangePassword;

/**
 * Servlet implementation class ChangePass
 */
@WebServlet("/ChangePass")
public class ChangePass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String uid,curps,newps,confps;
		
		try
		{
			uid=request.getParameter("uid");
			curps=request.getParameter("curps");
			newps=request.getParameter("newps");
			confps=request.getParameter("confps");
			
			
			ChangePassword cp = new ChangePassword();
			cp.setUid(uid);
			cp.setCpswd(curps);
			cp.setNpswd(newps);
			cp.setCopswd(confps);
			
			if(cp.isFlag())
			{
				out.print("<html><head><link rel='stylesheet' href='bootstrap.min.css'><br><br><div class='container'><h3>Password Changed Successfully</h3></div></head></html>");
			}
			else
			{
				out.print("<html><head><link rel='stylesheet' href='bootstrap.min.css'><br><br><div class='container'><h3 style='color:red'>Failed</h3></div></head></html>");
			}
		}
		catch(Exception e)
		{
			out.print(e.getMessage());
		}
		
	}
	

}
