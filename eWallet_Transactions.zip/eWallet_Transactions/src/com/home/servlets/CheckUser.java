package com.home.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.beans.DBConnector;


/**
 * Servlet implementation class CheckUser
 */
@WebServlet("/CheckUser")
public class CheckUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String uid,pswd,typ;
		uid=request.getParameter("uid");
		pswd=request.getParameter("pswd");
		
		try
		{
			Connection con;
			PreparedStatement pst;
			ResultSet rs;
			
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		    pst=con.prepareStatement("select * from users where userid=? and pswd=? and userstatus='active';");
			pst.setString(1, uid);
			pst.setString(2, pswd);
			rs=pst.executeQuery();
			if(rs.next())
			{
				
				HttpSession ses=request.getSession(true);
				ses.setAttribute("userid", uid);
				
				typ=rs.getString("usertype");
				
				
				if(rs.getString("usertype").equals("user"))
				response.sendRedirect("user.jsp");
				
				if(rs.getString("usertype").equals("admin"))
					response.sendRedirect("admin.jsp");
				
			}
			else
			{
				response.sendRedirect("failure.jsp");
			}
			
		}
		catch(Exception e)
		{
			out.println("Error : "+e.getMessage());
		}
	}

}
