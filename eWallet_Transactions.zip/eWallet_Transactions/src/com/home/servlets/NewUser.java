package com.home.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.home.beans.NewUserRegistration;

/**
 * Servlet implementation class NewUser
 */
@WebServlet("/NewUser")
public class NewUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String uid,pswd,unm,gen,city,mobile,email,sqque,ans;
		int age;
		
		try
		{
			uid=request.getParameter("uid");
			pswd=request.getParameter("pswd");
			unm=request.getParameter("unm");
			age=Integer.parseInt(request.getParameter("age"));
			gen=request.getParameter("gender");
			city=request.getParameter("city");
			mobile=request.getParameter("mobile");
			email=request.getParameter("email");
			sqque=request.getParameter("sqque");
			ans=request.getParameter("ans");
			
			
			NewUserRegistration nus= new NewUserRegistration();
			nus.setUid(uid);
			nus.setPswd(pswd);
			nus.setUnm(unm);
			nus.setAge(age);
			nus.setGender(gen);
			nus.setCity(city);
			nus.setMobile(mobile);
			nus.setEmail(email);
			nus.setSqque(sqque);
			nus.setAns(ans);
			
			if(nus.isStatus()==true)
			{
				response.sendRedirect("success.html");
			}
			else
			{
				response.sendRedirect("failed.html");
			}
		}
		catch(Exception e)
		{
			out.println("Error : "+e.getMessage());
		}
	}

}
