package com.home.beans;
import java.sql.*;

import com.connection.beans.DBConnector;
public class ChangePassword
{
	private String uid;
	private String cpswd;
	private String npswd;
	private String copswd;
	private boolean flag;
	
	public ChangePassword()
	{
		uid="";
		cpswd="";
		npswd="";
		copswd="";
	}

	public boolean isFlag() {
		return flag;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public void setCpswd(String cpswd) {
		this.cpswd = cpswd;
	}

	public void setNpswd(String npswd) {
		this.npswd = npswd;
	}

	public void setCopswd(String copswd)
	{
		this.copswd = copswd;
		onChange();
	}
	
	public void onChange()
	{
		Connection con;
		PreparedStatement pst;
		
		try
		{
			if(npswd.equals(copswd))
			{
				try
				{
					DBConnector dbc= new DBConnector();
				    con=dbc.getDbconnection();
				    pst=con.prepareStatement("update users set pswd=? where userid=? and pswd=?;");
				    pst.setString(1, npswd);
				    pst.setString(2, uid);
				    pst.setString(3, cpswd);
				    int cnt=pst.executeUpdate();
				    if(cnt==1)
				    	flag=true;
				    else
				    	System.out.println("Password change failed");
				con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
			else
			{
				System.out.println("New Passwords Mismatched");
			}
			
		}
		catch(Exception e)
		{
			System.out.println("Error : "+e.getMessage());
		}
	}
}
