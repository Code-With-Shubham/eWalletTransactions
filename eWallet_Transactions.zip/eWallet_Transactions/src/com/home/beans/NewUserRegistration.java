package com.home.beans;
import java.sql.*;
import com.connection.beans.DBConnector;
public class NewUserRegistration 
{
	private String uid;
	private String pswd;
	private String unm;
	private int age;
	private String gender;
	private String city;
	private String mobile;
	private String email;
	private String sqque;
	private String ans;
	
	private boolean status;
	
	public NewUserRegistration()
	{
		uid=" ";
		pswd=" ";
		unm=" ";
		age=0;
		gender=" ";
		city=" ";
		mobile=" ";
		email=" ";
		sqque=" ";
		ans=" ";
		status=false;
	}
	
	

	public boolean isStatus() {
		return status;
	}



	public void setUid(String uid) {
		this.uid = uid;
	}



	public void setPswd(String pswd) {
		this.pswd = pswd;
	}



	public void setUnm(String unm) {
		this.unm = unm;
	}



	public void setAge(int age) {
		this.age = age;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public void setMobile(String mobile) {
		this.mobile = mobile;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public void setSqque(String sqque) {
		this.sqque = sqque;
	}



	public void setAns(String ans) {
		this.ans = ans;
		onSubmission();
	}



	private void onSubmission()
	{
		Connection con;
		PreparedStatement pst;
		
		try
		{
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		    
				pst=con.prepareStatement("insert into users values(?,?,?,?,default);");
				pst.setString(1, uid);
				pst.setString(2, pswd);
				pst.setString(3, unm);
				pst.setString(4, "user");
				int st=pst.executeUpdate();
				if(st>0)
				{
					pst=con.prepareStatement("insert into userpersonal values(?,?,?,?,?,?,?,?);");
					pst.setString(1, uid);
					pst.setInt(2, age);
					pst.setString(3, gender);
					pst.setString(4, city);
					pst.setString(5, mobile);
					pst.setString(6, email);
					pst.setString(7, sqque);
					pst.setString(8, ans);
					int st1=pst.executeUpdate();
					if(st1>0)
					{
						status=true;
					}
				}	
				con.close();
				pst.close();
		}
		catch(Exception e)
		{
			System.out.print("Error : "+e.getMessage());
			status=false;
		}
	}
}
