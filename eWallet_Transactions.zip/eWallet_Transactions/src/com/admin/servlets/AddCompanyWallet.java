package com.admin.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.admin.beans.CompanyWallet;


/**
 * Servlet implementation class AddCompanyWallet
 */
@WebServlet("/AddCompanyWallet")
public class AddCompanyWallet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCompanyWallet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		try
		{
			
	     	String uid=request.getParameter("uid");
			String email=request.getParameter("email");
			Random rnd = new Random();
			int wid = rnd.nextInt(999999);
			 
			CompanyWallet cw = new CompanyWallet();
			cw.setUid(uid);
			cw.setWid(wid);
			cw.setEmail(email);
			
					if(cw.isFlag())
					{
						out.print("<html><head><link rel='stylesheet' href='bootstrap.min.css'></head><body><br><br><div class='container'><h2>Wallet Id Is "+wid+"</h2><br><hr><br><a href='admin.jsp'>Home</a></div>></body></html>");
					}
					else
					{
						out.print("Failed");
					}
		}		
		catch(Exception e)
		{
			out.print(e.getMessage());
		}
	}

}
