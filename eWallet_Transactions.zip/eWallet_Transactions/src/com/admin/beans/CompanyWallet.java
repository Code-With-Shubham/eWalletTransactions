package com.admin.beans;
import java.sql.*;


import com.connection.beans.DBConnector;

public class CompanyWallet 
{
	private String uid;
	private int wid;
	private String email;
	private boolean flag;
	public CompanyWallet()
	{
		uid="";
		wid=0;
		email="";
		flag=false;
	}
	
	
	public boolean isFlag() {
		return flag;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}


	public void setWid(int wid) {
		this.wid = wid;
	}


	public void setEmail(String email) {
		this.email = email;
		onChange();
	}


	public void onChange()
	{
		Connection con;
		PreparedStatement pst;
		try
		{
			
			
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		
			pst=con.prepareStatement("insert into wallet values(?,?,?,?);");
			pst.setString(1, uid);
			pst.setInt(2, wid);
			pst.setString(3, email);
			pst.setDouble(4, 500);
			int st1=pst.executeUpdate();
			if(st1>0)
			{
				pst=con.prepareStatement("insert into wallet_transaction values(?,?,?,?,now());");
				pst.setString(1, uid);
				pst.setInt(2, wid);
				pst.setString(3, "Deposite");
				pst.setDouble(4, 500);
				int st2=pst.executeUpdate();
				if(st2>0)
					flag=true;
				else
					System.out.print("Failed bean");
			}
			System.out.print("Transaction Not Updated");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
}
