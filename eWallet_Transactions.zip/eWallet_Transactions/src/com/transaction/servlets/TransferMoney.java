package com.transaction.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.beans.DBConnector;
import com.transactions.beans.MoneyTransfer;

/**
 * Servlet implementation class TransferMoney
 */
@WebServlet("/TransferMoney")
public class TransferMoney extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransferMoney() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String uid=request.getSession(false).getAttribute("userid").toString();
		double amt=Double.parseDouble(request.getParameter("amt"));
		int towid=Integer.parseInt(request.getParameter("towid"));
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		try
		{
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		    pst=con.prepareStatement("select walletid from wallet where userid=?;");
			pst.setString(1, uid);
			rs=pst.executeQuery();
			if(rs.next())
			{
				int wid=rs.getInt("walletid");
				
				
				MoneyTransfer mt = new MoneyTransfer();
				mt.setUid(uid);
				mt.setFwid(wid);
				mt.setTwid(towid);
				mt.setAmt(amt);
				
				if(mt.isFlag())
				{
					response.sendRedirect("successtransaction.jsp");
				}
				else
					out.print("Transation Failed");
				
				
			}
		}
		catch(Exception e)
		{
			out.print(e);
		}
	}

}
