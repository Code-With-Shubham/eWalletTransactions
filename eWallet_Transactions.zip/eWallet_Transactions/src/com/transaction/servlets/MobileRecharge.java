package com.transaction.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.connection.beans.DBConnector;
import com.transactions.beans.MoneyTransfer;

/**
 * Servlet implementation class MobileRecharge
 */
@WebServlet("/MobileRecharge")
public class MobileRecharge extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MobileRecharge() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String comp;
		double amt;
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			comp=request.getParameter("comp");
			amt=Integer.parseInt(request.getParameter("amt"));
			String uid=request.getSession(false).getAttribute("userid").toString();
			
			
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		    pst=con.prepareStatement("select walletid from wallet where userid=?;");
			pst.setString(1, uid);
			rs=pst.executeQuery();
			if(rs.next())
			{
					int fwid=rs.getInt("walletid");
				 	pst=con.prepareStatement("select walletid from wallet where userid=?;");
					pst.setString(1, comp);
					rs=pst.executeQuery();
					if(rs.next())
					{
						int twid=rs.getInt("walletid");				
				
				
							MoneyTransfer mt = new MoneyTransfer();
							mt.setUid(uid);
							mt.setFwid(fwid);
							mt.setTwid(twid);
							mt.setAmt(amt);
							
							if(mt.isFlag())
							{
								response.sendRedirect("successrecharge.html");
							}
					}
					out.print("Companies WalletID Not Found");
			}
			out.print("WalletID Not Found");
		}
		catch(Exception e)
		{
			out.print(e.getMessage());
		}
	}

}
