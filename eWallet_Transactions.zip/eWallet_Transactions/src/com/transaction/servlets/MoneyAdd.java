package com.transaction.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.beans.DBConnector;
import com.transactions.beans.AddMoney;

/**
 * Servlet implementation class MoneyAdd
 */
@WebServlet("/MoneyAdd")
public class MoneyAdd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MoneyAdd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String uid=request.getSession(false).getAttribute("userid").toString();
		double amt=Double.parseDouble(request.getParameter("amt"));
		
		
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		    pst=con.prepareStatement("select walletid from wallet where userid=?;");
			pst.setString(1, uid);
			rs=pst.executeQuery();
			if(rs.next())
			{
				int wid=rs.getInt("walletid");
				
				AddMoney am = new AddMoney();
				am.setUid(uid);
				am.setWid(wid);
				am.setAmt(amt);
				
				if(am.isFlag())
				{
					response.sendRedirect("successmoneyadd.html");
				}
			}
			else
			{
				out.println("Wallet Id Not Found");
			}
			
			con.close();
			pst.close();
		}
		catch(Exception e)
		{
			out.print(e.getMessage());
		}

		
	}

}
