package com.upload.servlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.connection.beans.DBConnector;

/**
 * Servlet implementation class FileUpload
 */
@WebServlet("/FileUpload")
@MultipartConfig(maxFileSize=16177215)
public class FileUpload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileUpload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("html/text/charset=UTF-8");
		
		try
		{
			    String uid = request.getParameter("uid");
		        String email = request.getParameter("email");
		        String aadhar = request.getParameter("aadhar");
		      
		        Part filePart = request.getPart("aadhardoc");
		        String filename = filePart.getSubmittedFileName();
		      
		        String path = getServletContext().getRealPath("/"+"AadharDoc"+File.separator+filename);
		        
		        InputStream is = filePart.getInputStream();
		        boolean succes=uploadFile(is,path);
		        if(succes)
		        {
		        	
		        }
		}
		catch(Exception e)
		{
			out.print("Error : "+e.getMessage());
		}
		
		
       
	}
	public boolean uploadFile(InputStream is, String path)
	{
		boolean test = false;
		
		try
		{
			byte[] byt = new byte[is.available()];
			is.read();
			FileOutputStream fops = new FileOutputStream(path);
			fops.write(byt);
			fops.flush();
			fops.close();
			
			test=true;
		}
		catch(Exception e)
		{
			
		}
		return test;
	}
}