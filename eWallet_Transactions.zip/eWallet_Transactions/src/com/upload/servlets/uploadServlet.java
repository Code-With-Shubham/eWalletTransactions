package com.upload.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.*;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.connection.beans.DBConnector;

/**
 * Servlet implementation class uploadServlet
 */
@MultipartConfig(maxFileSize=16177215)  //for min 16 Mb of file
@WebServlet("/uploadServlet")
public class uploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public uploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		String uid,email,aadhar,image;
		try
		{
			uid=request.getParameter("uid");
			int accno=Integer.parseInt(request.getParameter("accno"));
			email=request.getParameter("email");
			aadhar=request.getParameter("aadhar");
			image=request.getParameter("aadhardoc");
			
			Connection con;
			PreparedStatement pst;
			
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		    
				pst=con.prepareStatement("insert into kycdoc values(?,?,?,?,?,now());");
				pst.setString(1, uid);
				pst.setInt(2, accno);
				pst.setString(3, email);
				pst.setString(4, aadhar);
				pst.setString(5, "image");
				int st=pst.executeUpdate();
				if(st>0)
				{
					Random rnd = new Random();
					int number = rnd.nextInt(999999);
					pst=con.prepareStatement("insert into wallet values(?,?,?,?);");
					pst.setString(1, uid);
					pst.setInt(2, number);
					pst.setString(3, email);
					pst.setDouble(4, 500);
					int st1=pst.executeUpdate();
					if(st1>0)
					{
						pst=con.prepareStatement("insert into wallet_transaction values(?,?,?,?,now());");
						pst.setString(1, uid);
						pst.setInt(2, number);
						pst.setString(3, "Deposite");
						pst.setDouble(4, 500);
						int st2=pst.executeUpdate();
						if(st2>0)
							out.print("<html><head><link rel='stylesheet' href='bootstrap.min.css'></head><body><br><br><div class='container'><h2>Wallet Id Is "+number+"</h2><br><hr><br><a href='user.jsp'>Home</a></div>></body></html>");
						else
							out.print("Failed");
					}
					else
					{
						response.sendRedirect("failure.html");
					}
					//must pay 500 at the time of registration on eWallet
				}
				else
				{
				     out.print("<html><head><link rel='stylesheet' href='bootstrap.min.css'></head><body><br><br><div class='container'><h2 style='color:red'>Authentication Failed <br> Or <br> Your KYC is Already Done.</h2><br><hr><br><a href='user.jsp'>Home</a></div>></body></html>");
				}
				
		}catch(Exception e)
		{
			out.println(e.getMessage());
			out.print("<html><head><link rel='stylesheet' href='bootstrap.min.css'></head><body><br><br><div class='container'><h2>Authentication Failed <br> Or <br> Your KYC is Already Done.</h2><br><hr><br>&copy;eWallet Transactions<br>\r\n"
					+ "Developed By shubhammanohare88@gmail.com<br>\r\n"
					+ "Powered By SohamGlobal</div>></body></html>");
		}
	}
}
			
			
			
			
			
			
			
			
			/*InputStream inputStream = null;
			
			Part filePart = request.getPart("photo");
	        if (filePart != null)
	        {
	            // prints out some information for debugging
	            System.out.println(filePart.getName());
	            System.out.println(filePart.getSize());
	            System.out.println(filePart.getContentType());
	            
	            inputStream = filePart.getInputStream();
	        }
	        
		
        
	        	Connection conn = null; // connection to the database
	        	
	        	DBConnector dbc= new DBConnector();
	        	conn=dbc.getDbconnection();
	    
	        	String sql = "INSERT INTO kycdoc (userid, email, aadhar, image, dt) values (?, ?, ?, ?,now())";
	        	PreparedStatement statement = conn.prepareStatement(sql);
	        	statement.setString(1, uid);
	        	statement.setString(2, email);
        		statement.setString(3, aadhar);
	    
        		if (inputStream != null) 
        		{
        			statement.setBlob(4, inputStream);
        			int row = statement.executeUpdate();
        			if (row > 0)
        		 	message = "File uploaded and saved into database";     
        		}
	    conn.close();
        }
		catch (SQLException ex)
		{
			message = "ERROR: " + ex.getMessage();
			ex.printStackTrace();
		}
		
		
		request.setAttribute("Message", message);
          getServletContext().getRequestDispatcher("/Message.jsp").forward(request, response);
          */
