package com.transactions.beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.connection.beans.DBConnector;

public class AddMoney
{
	private String uid;
	private int wid;
	private double amt;
	private boolean flag;
	
	public AddMoney()
	{
		uid="";
		wid=0;
		amt=0.0;
		flag=false;
		
	}

	public boolean isFlag() {
		return flag;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public void setWid(int wid) {
		this.wid = wid;
	}

	public void setAmt(double amt)
	{
		this.amt = amt;
		onClick();
	}
	
	public void onClick()
	{
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
				pst=con.prepareStatement("update wallet set balance=balance+? where walletid=? and userid=?;");
				pst.setDouble(1, amt);
				pst.setInt(2, wid);
				pst.setString(3, uid);
				int cnt=pst.executeUpdate();
				if(cnt>0)
				{
					pst=con.prepareStatement("insert into wallet_transaction values(?,?,?,?,now());");
					pst.setString(1, uid);
					pst.setInt(2, wid);
					pst.setString(3, "Deposite");
					pst.setDouble(4, amt);					
					int cnt1=pst.executeUpdate();
					if(cnt1>0)
					{
						flag=true;
					}
					else
						System.out.print("Transaction Not Saved");
				}
				else
					System.out.print("Failed");
			con.close();
			pst.close();
		}
		catch(Exception e)
		{
			System.out.print(e.getMessage());
		}
	}
}
