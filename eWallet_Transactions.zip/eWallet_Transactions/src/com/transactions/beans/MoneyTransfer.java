package com.transactions.beans;
import java.sql.*;

import com.connection.beans.DBConnector;
public class MoneyTransfer
{
	private String uid;
	private int fwid;
	private int twid;
	private double amt;
	private boolean flag;
	
	public MoneyTransfer()
	{
		uid="";
		fwid=0;
		twid=0;
		amt=0.0;
		flag=false;
		
	}

	public boolean isFlag() {
		return flag;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public void setFwid(int fwid) {
		this.fwid = fwid;
	}

	public void setTwid(int twid) {
		this.twid = twid;
	}

	public void setAmt(double amt) {
		this.amt = amt;
		onClick();
	}
	
	public void onClick()
	{
		Connection con;
		PreparedStatement pst;
		
		try
		{
			DBConnector dbc= new DBConnector();
		    con=dbc.getDbconnection();
		    
			pst=con.prepareStatement("update wallet set balance=balance-? where walletid=?;");
			pst.setDouble(1, amt);
			pst.setInt(2, fwid);
			int cnt=pst.executeUpdate();
			if(cnt>0)
			{
				pst=con.prepareStatement("update wallet set balance=balance+? where walletid=?;");
				pst.setDouble(1, amt);
				pst.setInt(2, twid);
				int cnt1=pst.executeUpdate();
				if(cnt1>0)
				{
					pst=con.prepareStatement("insert into wallet_transaction values(?,?,?,?,now());");
					pst.setString(1, uid);
					pst.setInt(2, fwid);
					pst.setString(3, "Withdrow");
					pst.setDouble(4, amt);					
					int cnt2=pst.executeUpdate();
					if(cnt2>0)
					{
						pst=con.prepareStatement("insert into wallet_transaction values(?,?,?,?,now());");
						pst.setString(1, uid);
						pst.setInt(2, twid);
						pst.setString(3, "Deposite");
						pst.setDouble(4, amt);					
						int cnt3=pst.executeUpdate();
						if(cnt3>0)
						{
							if(amt>=1000)
							{
								pst=con.prepareStatement("update wallet set balance=balance+? where walletid=?;");
								pst.setDouble(1, 50);
								pst.setInt(2, fwid);
								int cnt11=pst.executeUpdate();
								if(cnt11>0)
								{
									pst=con.prepareStatement("insert into wallet_transaction values(?,?,?,?,now());");
									pst.setString(1, uid);
									pst.setInt(2, fwid);
									pst.setString(3, "CashBack");
									pst.setDouble(4, 50);					
									int cnt22=pst.executeUpdate();
									if(cnt22>0)
									{
										 flag=true;
									}
								}	
							}
							else
							{
								flag=true;
							}
						}
						else
							System.out.print("Trnasaction Failed");
					}
					else
						System.out.print("Record Not Updated Properly");
				}
				else
					System.out.print("Trnasaction Failed");
		    }
			else
				System.out.print("Trnasaction Failed");
		}  
		catch(Exception e)
		{
			System.out.print(e.getMessage());
		}
    }
}
