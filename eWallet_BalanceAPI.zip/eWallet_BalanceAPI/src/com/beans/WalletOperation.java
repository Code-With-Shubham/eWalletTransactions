package com.beans;
import java.sql.*;
public class WalletOperation
{
	
	public Wallet searchBal(int wid)
	{
		Wallet obj=new Wallet();
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/eWallet_Transaction?user=root&password=shubham");
			pst=con.prepareStatement("select balance from wallet where walleid=?;");
			pst.setInt(1, wid);
			rs=pst.executeQuery();
			if(rs.next())
			{
				//obj.setWalletid(rs.getInt("walletid"));
				obj.setBalance(rs.getDouble("balance"));
			}
			else
			{
				
			}
			con.close();
			
		}
		catch(Exception e)
		{
			
	}
		return obj;
}
}