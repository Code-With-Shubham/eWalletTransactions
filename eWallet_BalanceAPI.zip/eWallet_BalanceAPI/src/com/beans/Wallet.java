package com.beans;

public class Wallet 
{
	private int walletid;
	private double balance;
	
	
	public Wallet()
	{
		walletid=0;
		balance=0.0;
	}


	public int getWalletid() {
		return walletid;
	}


	public void setWalletid(int walletid) {
		this.walletid = walletid;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
}
