package myrestapis;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.beans.Wallet;
import com.beans.WalletOperation;
@Path("/balance")
public class BalanceService
{
	@GET
	@Path("/{wid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Wallet getCelebInfo(@PathParam("wid") int wid)
	{
		WalletOperation wo=new WalletOperation();
		Wallet obj=wo.searchBal(wid);
		
		return(obj);
	}
}
